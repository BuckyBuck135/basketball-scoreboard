let scoreHomeEl = document.getElementById("score-home-el");
let scoreGuestEl = document.getElementById("score-guest-el");
let countHome = 0;
let countGuest = 0;

const divHomePulse = document.querySelector('.home-pulse');
const divGuestPulse = document.querySelector('.guest-pulse');

// Show a different cheer message accordiing to score //
const cheeringEl = document.getElementById("cheering")
function showCheerMessage() {
    if (countGuest > countHome) {
        cheeringEl.textContent = "Go Guest!"
    } else if (countHome > countGuest) {
        cheeringEl.textContent = "Go Home!"
    } else {
        cheeringEl.textContent = "Go Go Go!"
    }
}
showCheerMessage()

// Increment functions below//
function incrementHome1() {
    countHome += 1;
    scoreHomeEl.textContent=countHome;
    showCheerMessage()
}

function incrementHome2() {
    countHome += 2;
    scoreHomeEl.textContent=countHome;
    showCheerMessage()
}

function incrementHome3() {
    countHome += 3;
    scoreHomeEl.textContent=countHome;
    showCheerMessage()
}

function incrementGuest1() {
    countGuest += 1;
    scoreGuestEl.textContent=countGuest;
    showCheerMessage()
}

function incrementGuest2() {
    countGuest += 2;
    scoreGuestEl.textContent=countGuest;
    showCheerMessage()
}

function incrementGuest3() {
    countGuest += 3;
    scoreGuestEl.textContent=countGuest;
    showCheerMessage()
}
//end of increment functions//

function reset() {
    countHome = 0;
    countGuest = 0;
    scoreGuestEl.textContent=countGuest;
    scoreHomeEl.textContent=countHome;

}
// Conditional pulse CSS effct - currently not working as intended //
function scorePulseEffect() {
    if (countGuest > countHome) {
        divHomePulse.style.display = 'none';
        divGuestPulse.style.display = 'block';
    } else if (countHome > countGuest) {
        divHomePulse.style.display = 'block';
        divGuestPulse.style.display = 'none';
    } else if (countHome === countGuest){
        divHomePulse.style.display = 'none';
        divGuestPulse.style.display = 'none';
    }
}
// scorePulseEffect();


